package com.dms.standarddataserver.standardArea.service;

public interface StandardDataService {
}
