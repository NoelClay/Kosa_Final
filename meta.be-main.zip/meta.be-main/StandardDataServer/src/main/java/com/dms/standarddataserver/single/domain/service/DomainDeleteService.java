package com.dms.standarddataserver.single.domain.service;


import com.dms.standarddataserver.single.domain.dto.DomainDTO;

public interface DomainDeleteService {
    public  boolean deleteDomain(DomainDTO domainDTO);
}

