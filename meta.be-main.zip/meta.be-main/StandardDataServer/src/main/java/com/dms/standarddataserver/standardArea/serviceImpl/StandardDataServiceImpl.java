package com.dms.standarddataserver.standardArea.serviceImpl;

import org.springframework.stereotype.Service;

@Service
public class StandardDataServiceImpl {
}
