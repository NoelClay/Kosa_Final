package com.dms.standarddataserver.word.service;

public interface WordAndTermDeleteService {

    boolean deleteWordAndTerm(String deleteDicId);


}
