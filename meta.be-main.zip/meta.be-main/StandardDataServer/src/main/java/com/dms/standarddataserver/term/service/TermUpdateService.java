package com.dms.standarddataserver.term.service;

public interface TermUpdateService {

    boolean updateSingleTerm(String dicId, String domId, String dicDesc);


}
