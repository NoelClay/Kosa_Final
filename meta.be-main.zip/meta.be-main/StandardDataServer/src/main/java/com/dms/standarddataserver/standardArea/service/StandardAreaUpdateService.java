package com.dms.standarddataserver.standardArea.service;

import com.dms.standarddataserver.standardArea.dto.StandardAreaDTO;

public interface StandardAreaUpdateService {
     void update(StandardAreaDTO standardAreaDTO);
}
