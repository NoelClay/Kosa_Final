package com.dms.standarddataserver.domainGroup.service;

import com.dms.standarddataserver.domainGroup.dto.DomainGroupDTO;

import java.util.List;

public interface DomainGroupInsertService {
    public DomainGroupDTO insertDomainGroup(DomainGroupDTO domainGroupDto);
}
