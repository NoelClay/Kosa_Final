package com.dms.standarddataserver.single.domain.service;

import com.dms.standarddataserver.single.domain.dto.DomainDTO;

public interface DomainInfoService {

   public  DomainDTO getDomainInfo(String domId);
}
