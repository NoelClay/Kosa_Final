package com.dms.standarddataserver.single.domain.service;

import com.dms.standarddataserver.single.domain.dto.DomainDTO;

public interface DomainInsertService {

    public boolean insertDomain(DomainDTO domainDTO);

}
