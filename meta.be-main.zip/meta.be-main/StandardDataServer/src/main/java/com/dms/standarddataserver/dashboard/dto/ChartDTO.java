package com.dms.standarddataserver.dashboard.dto;

import lombok.Data;

@Data
public class ChartDTO {
    String element;
    String count;
}
