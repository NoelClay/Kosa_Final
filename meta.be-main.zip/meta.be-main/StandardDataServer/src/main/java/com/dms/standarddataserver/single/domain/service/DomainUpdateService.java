package com.dms.standarddataserver.single.domain.service;


import com.dms.standarddataserver.single.domain.dto.DomainDTO;


public interface DomainUpdateService {

    public int updateDomain(DomainDTO domainDTO);
}
