package com.dms.standarddataserver.standardArea.service;

public interface StandardAreaCheckDuplicateService {
  public Boolean checkIfDuplicate(String standardAreaName);
}
