package com.dms.standarddataserver.standardArea.service;

import com.dms.standarddataserver.standardArea.dto.StandardAreaDTO;

public interface StandardAreaInsertService {
    public void insert(StandardAreaDTO standardAreaDTO);
}
