package com.dms.standarddataserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StandardDataServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
