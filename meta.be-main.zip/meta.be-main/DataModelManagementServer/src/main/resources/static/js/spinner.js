function showLoadingSpinner() {
    // Display the loading spinner
    document.getElementById('loading-spinner').style.display = 'block';
}
function hideLoadingSpinner() {
    // Hide the loading spinner
    document.getElementById('loading-spinner').style.display = 'none';
}