package com.dms.datamodelmanagementserver.standardArea.service;


public interface StandardAreaCheckDuplicateService {
    boolean checkIfDuplicate(String standardAreaName);
}
