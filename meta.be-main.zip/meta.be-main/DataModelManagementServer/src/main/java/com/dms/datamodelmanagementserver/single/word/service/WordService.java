package com.dms.datamodelmanagementserver.single.word.service;

import com.dms.datamodelmanagementserver.single.word.dto.WordDTO;

public interface WordService {

    boolean singleWordInsertRest(WordDTO wordDTO);



}
