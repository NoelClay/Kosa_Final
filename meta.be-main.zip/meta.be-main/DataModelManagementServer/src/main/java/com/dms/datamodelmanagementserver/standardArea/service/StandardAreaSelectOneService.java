package com.dms.datamodelmanagementserver.standardArea.service;

import com.dms.datamodelmanagementserver.standardArea.dto.StandardAreaDTO;

public interface StandardAreaSelectOneService {
	public StandardAreaDTO selectOne(String standardAreaName);
}
