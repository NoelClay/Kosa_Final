package com.dms.datamodelmanagementserver.single.word.service;

import com.dms.datamodelmanagementserver.single.word.dto.WordDTO;

public interface WordUpdateService {

    boolean singleWordUpdateRest(WordDTO wordDTO);


}
