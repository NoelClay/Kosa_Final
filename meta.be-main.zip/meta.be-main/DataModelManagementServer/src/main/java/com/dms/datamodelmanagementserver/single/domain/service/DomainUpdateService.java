package com.dms.datamodelmanagementserver.single.domain.service;

import com.dms.datamodelmanagementserver.single.domain.dto.DomainDTO;

public interface DomainUpdateService {

    public DomainDTO singleDomainUpdateRest(DomainDTO domainDTO);

}
