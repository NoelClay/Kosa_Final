package com.dms.datamodelmanagementserver.global;

public enum DomainType {
   일반,번호,코드
}
