package com.dms.datamodelmanagementserver.standardArea.service;

import com.dms.datamodelmanagementserver.standardArea.dto.StandardAreaDTO;

public interface StandardAreaUpdateService {
    boolean update(StandardAreaDTO standardAreaDTO);
}
