package com.dms.datamodelmanagementserver.single.word.service;

public interface WordAndTermDeleteService {

    boolean deleteWordAndTermRest(String deleteDicId);

}
