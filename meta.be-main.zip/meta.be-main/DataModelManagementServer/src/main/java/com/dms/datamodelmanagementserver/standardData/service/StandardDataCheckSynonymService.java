package com.dms.datamodelmanagementserver.standardData.service;

import com.dms.datamodelmanagementserver.standardData.dto.StandardDataDTO;

public interface StandardDataCheckSynonymService {
    StandardDataDTO checkSynonym(StandardDataDTO standardDataDTO);
}
