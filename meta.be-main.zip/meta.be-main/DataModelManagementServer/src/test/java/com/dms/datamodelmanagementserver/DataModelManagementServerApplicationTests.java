package com.dms.datamodelmanagementserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataModelManagementServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
