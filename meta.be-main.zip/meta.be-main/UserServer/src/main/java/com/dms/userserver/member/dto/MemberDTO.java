package com.dms.userserver.member.dto;

import lombok.Data;

@Data
public class MemberDTO {
    private String id;
    private String password;
    private String name;
}
